from flask import Flask, request, render_template, jsonify
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import pandas as pd


app = Flask(__name__)

# Load data
movie_data = pd.read_csv('C:/Users/DELL/Desktop/data/movie_dataset.csv')

# Fill missing genres with empty strings
movie_data['genres'] = movie_data['genres'].fillna('')

# Convert all movie titles to lowercase for better matching
movie_data['title'] = movie_data['title'].str.lower()

# Convert genres to TF-IDF matrix
tfidf = TfidfVectorizer(stop_words='english')
tfidf_matrix = tfidf.fit_transform(movie_data['genres'])

# Compute similarity matrix
cosine_sim_content = cosine_similarity(tfidf_matrix, tfidf_matrix)

# Function to find the best matching movie and recommend similar ones
def recommend_movie(user_input, top_n=10):
    user_input = user_input.lower().strip()  # Convert input to lowercase and remove extra spaces
    
    # Find the best matching movie
    matched_movies = movie_data[movie_data['title'].str.contains(user_input, case=False, na=False)]
    
    if matched_movies.empty:
        return {"message": f"No exact match found for '{user_input}'. Try another title."}

    # Take the first matched movie
    movie_idx = matched_movies.index[0]
    
    # Get similarity scores
    sim_scores = list(enumerate(cosine_sim_content[movie_idx]))
    sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)

    # Get Top N similar movies (excluding itself)
    similar_movies = [movie_data.iloc[i[0]]['title'].title() for i in sim_scores[1:top_n+1]]
    
    return {"selected_movie": matched_movies.iloc[0]['title'].title(), "recommendations": similar_movies}

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/recommender', methods=['POST'])
def recommend():
    movie_name = request.form.get('movie_name')
    recommendations = recommend_movie(movie_name)
    return jsonify(recommendations)

if __name__ == '__main__':
    app.run(debug=True)
